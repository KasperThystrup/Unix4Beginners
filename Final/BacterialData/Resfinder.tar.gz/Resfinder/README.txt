In this directory are the assemblies from the Daycare outbreak.
