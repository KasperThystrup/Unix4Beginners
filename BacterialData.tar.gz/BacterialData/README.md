# Unix4Beginners
This repository contains the dataset alongside the solutions.

## Structure
 * Solutions/ - Folder which contains sorted sample files for use in case course exercise didn't work out as expected
 * Solutions/ResFinder - Folder which contains ResFinder results. If you dpn't wish spoilers, keep out ;-)
 * All other folders are part of the exercises, and should be considered as the course dataset
